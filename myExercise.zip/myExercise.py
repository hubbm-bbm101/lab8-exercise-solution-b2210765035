import sys
with open(sys.argv[1], "r") as stu:
    inputs = sys.argv[2].split(",") if len(sys.argv[2]) > 1 else sys.argv[2]
    names = stu.read().split("\n")
    content = []
    for i in names:
        content.append(i.split(":"))
    class NameNotFoundError(Exception):
        pass
    for i in inputs:
        try:
            if i == content[0][0]:
                print(f"Name:{content[0][0]}, University:{content[0][1]}")
            elif i == content[1][0]:
                print(f"Name:{content[1][0]}, University:{content[1][1]}")
            elif i == content[2][0]:
                print(f"Name:{content[2][0]}, University:{content[2][1]}")
            elif i == content[3][0]:
                print(f"Name:{content[3][0]}, University:{content[3][1]}")
            else:
                raise NameNotFoundError
        except NameNotFoundError:
            print(f"No record of '{i}' was found!")
